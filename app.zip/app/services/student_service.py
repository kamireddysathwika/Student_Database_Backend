from sqlmodel import Session, select

from app.models.student import Student
from app.schemas.student import StudentCreate, StudentUpdate


def create_student(session: Session, student_data: StudentCreate):

    student = Student(
        name=student_data.name,
        age=student_data.age,
        email=student_data.email,
        department=student_data.department,
        cgpa=student_data.cgpa
    )

    session.add(student)
    session.commit()
    session.refresh(student)

    return student


def get_students(session: Session):

    statement = select(Student)

    students = session.exec(statement).all()

    return students


def get_student(session: Session, student_id: int):

    return session.get(Student, student_id)


def update_student(
    session: Session,
    student_id: int,
    student_data: StudentUpdate
):

    student = session.get(Student, student_id)

    if not student:
        return None

    update_data = student_data.model_dump(exclude_unset=True)

    for key, value in update_data.items():
        setattr(student, key, value)

    session.add(student)
    session.commit()
    session.refresh(student)

    return student


def delete_student(session: Session, student_id: int):

    student = session.get(Student, student_id)

    if not student:
        return False

    session.delete(student)
    session.commit()

    return True