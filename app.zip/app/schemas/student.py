from sqlmodel import SQLModel


class StudentCreate(SQLModel):
    name: str
    age: int
    email: str
    department: str
    cgpa: float


class StudentRead(SQLModel):
    id: int
    name: str
    age: int
    email: str
    department: str
    cgpa: float


class StudentUpdate(SQLModel):
    name: str | None = None
    age: int | None = None
    email: str | None = None
    department: str | None = None
    cgpa: float | None = None