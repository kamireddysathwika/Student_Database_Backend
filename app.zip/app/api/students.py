from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from app.database.database import get_session
from app.schemas.student import (
    StudentCreate,
    StudentRead,
    StudentUpdate
)

from app.services.student_service import (
    create_student,
    get_students,
    get_student,
    update_student,
    delete_student
)


router = APIRouter(
    prefix="/students",
    tags=["Students"]
)


@router.post("/", response_model=StudentRead)
def add_student(
    student: StudentCreate,
    session: Session = Depends(get_session)
):
    return create_student(session, student)


@router.get("/", response_model=list[StudentRead])
def read_students(
    session: Session = Depends(get_session)
):
    return get_students(session)


@router.get("/{student_id}", response_model=StudentRead)
def read_student(
    student_id: int,
    session: Session = Depends(get_session)
):
    student = get_student(session, student_id)

    if not student:
        raise HTTPException(
            status_code=404,
            detail="Student not found"
        )

    return student


@router.put("/{student_id}", response_model=StudentRead)
def edit_student(
    student_id: int,
    student: StudentUpdate,
    session: Session = Depends(get_session)
):
    updated_student = update_student(
        session,
        student_id,
        student
    )

    if not updated_student:
        raise HTTPException(
            status_code=404,
            detail="Student not found"
        )

    return updated_student


@router.delete("/{student_id}")
def remove_student(
    student_id: int,
    session: Session = Depends(get_session)
):
    deleted = delete_student(session, student_id)

    if not deleted:
        raise HTTPException(
            status_code=404,
            detail="Student not found"
        )

    return {
        "message": "Student deleted successfully"
    }