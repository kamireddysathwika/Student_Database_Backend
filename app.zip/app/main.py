from fastapi import FastAPI

from app.database.database import create_db_and_tables
from app.api.students import router as student_router

app = FastAPI(
    title="Student Database Application System",
    description="Backend API for Student Database with AI Chatbot",
    version="1.0.0"
)

@app.on_event("startup")
def startup():
    create_db_and_tables()

app.include_router(student_router)

@app.get("/")
def home():
    return {
        "message": "Student Database Backend is running"
    }
